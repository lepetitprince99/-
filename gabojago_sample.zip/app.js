const places = [
  {name:'경복궁', type:'관광지', area:'서울', desc:'고궁 산책과 야간 관람으로 인기 있는 서울 대표 명소'},
  {name:'해운대 해수욕장', type:'관광지', area:'부산', desc:'바다 풍경과 주변 맛집을 함께 즐기기 좋은 장소'},
  {name:'전주 한옥마을', type:'관광지', area:'전북', desc:'한옥 거리, 먹거리, 전통 체험을 함께 즐길 수 있는 여행지'},
  {name:'성산일출봉 근처 카페', type:'카페', area:'제주', desc:'오션뷰와 사진 명소를 함께 즐기는 제주 감성 카페'},
];

const list = document.querySelector('#placeList');
const regions = document.querySelector('#regionCards');

function renderPlaces(data){
  if (!list) return;
  list.innerHTML = data.map(p => `
    <article class="place-card">
      <div class="thumb">사진</div>
      <div>
        <span class="tag">${p.area} · ${p.type}</span>
        <h3>${p.name === '경복궁' ? `<a href='gyeongbokgung.html'>${p.name}</a>` : p.name}</h3>
        <p>${p.desc}</p>
      </div>
      <button onclick="p.name === '경복궁' ? location.href='gyeongbokgung.html' : alert(p.name + ' 상세 페이지는 샘플 준비 중입니다.')">상세보기</button>
    </article>
  `).join('');
}

function renderRegions(){
  if (!regions) return;
  const data = ['서울','부산','대구','인천','제주','전주'];
  regions.innerHTML = data.map(r => `<article class="region-card" ${r === '서울' ? "onclick=\"location.href='seoul.html'\" style=\"cursor:pointer\"" : ''}><span class="tag">${r}</span><h3>${r} 추천 여행</h3><p>관광지, 맛집, 카페를 묶어서 추천합니다.</p></article>`).join('');
}

function searchKeyword(){
  const input = document.querySelector('#mainSearch');
  const keyword = input ? input.value.trim() : '';
  if (keyword) {
    location.href = `all.html?keyword=${encodeURIComponent(keyword)}`;
  } else {
    alert('검색어를 입력해주세요.');
  }
}

function makeCourse(){
  const input = document.querySelector('#promptInput')?.value.trim();
  const result = document.querySelector('#courseResult');
  if (!result) return;

  result.innerHTML = `
    <h2>AI 추천 코스 예시</h2>
    <p><b>요청:</b> ${input || '서울에서 역사와 산책을 함께 즐기는 당일치기 코스'}</p>
    <ol class="course-list">
      <li><b>1코스:</b> 경복궁에서 조선 궁궐의 분위기 느끼기</li>
      <li><b>2코스:</b> 북촌 한옥마을에서 전통 골목 산책하기</li>
      <li><b>3코스:</b> 인사동 거리에서 전통 공예품과 카페 즐기기</li>
    </ol>

    <h3 class="recommend-card-title">추천 관광지 3곳</h3>
    <div class="ai-place-cards">
      <a class="ai-place-card" href="gyeongbokgung.html">
        <div class="ai-place-img">이미지</div>
        <h4>경복궁</h4>
        <p>조선 왕조의 법궁이자 서울 대표 역사 관광지</p>
      </a>
      <article class="ai-place-card">
        <div class="ai-place-img">이미지</div>
        <h4>북촌 한옥마을</h4>
        <p>한옥 골목과 전통 분위기를 느낄 수 있는 산책 명소</p>
      </article>
      <article class="ai-place-card">
        <div class="ai-place-img">이미지</div>
        <h4>인사동 거리</h4>
        <p>전통 공예품, 찻집, 갤러리를 함께 즐기는 거리</p>
      </article>
    </div>
  `;
}

document.querySelectorAll('.chips button').forEach(btn => btn.addEventListener('click', () => {
  const input = document.querySelector('#mainSearch');
  if (!input) return;
  input.value = btn.dataset.keyword;
  searchKeyword();
}));

renderPlaces(places);
renderRegions();
